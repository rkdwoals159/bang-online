# 06. 구현 수락 시나리오

이 문서는 **향후 구현용 명세**다. 현재 실행한 테스트나 통과 결과가 아니다. 구현 요청 시 T42/T60 담당자가 테스트 코드를 작성하고 요청된 검증 범위에서 실행한다. 고정 RNG/덱/역할/HP fixture를 사용하고, 각 시나리오는 입력 전후 state 및 사용자별 projection을 함께 비교한다. 오류 시 HP·카드 위치·version 변화가 없어야 한다.

## 공통 fixture 계약

- 좌석 A→B→C→D→E→F→G는 시계 방향. 명시하지 않은 플레이어는 생존 HP4, 손패0, 장착없음. 보안관 A. 필요한 승리 조건을 막을 때 E 무법자 생존을 명시한다.
- 덱은 배열 첫 원소가 top. discard도 구현 내부 방향을 정하되 명세 배열은 먼저 버림→마지막 top 순서. runtime 카드 ID는 unique opaque ID다.
- 테스트 준비는 fixture builder로 유효한 80장 분배를 만든다. 한 카드를 여러 구역에 복제하지 않는다. 특정 카드가 부족한 비정상 상태는 명시적으로 corruption 사례라고 표시한다.
- 모든 명령에는 인증 actor, expectedVersion, commandId를 준다. pending 응답은 interactionId가 일치해야 한다.
- 각 케이스에 자동화 파일 경로·명령·실제 결과를 구현 시 붙인다. 아래 expected만으로 DONE 처리하지 않는다.

## A. 시작·턴·공간·덱

| ID | Given / When | Then | 규칙 |
|---|---|---|---|
| A01 | 4/5/6/7인 각각 시작 | 역할 구성이 R02와 일치, 보안관만 공개, 모든 인물 다름 |R01–03|
| A02 | Paul 보안관으로 시작 | max/start HP4, 손패4; 일반 Paul은3 |R03|
| A03 | 정상 시작 | 보안관부터, 나머지 순서 시계방향; 각 시작패 HP만큼 |R03|
| A04 | 역할 배정 snapshot을 각 actor로 요청 | 다른 비공개 역할과 손패 face/ID 없음 |R04|
| A05 | 정상 턴 시작→사용 종료 | draw2 후 PLAY; hand>HP면 DISCARD pending |R05,R07|
| A06 | HP3 손패5에서 턴 종료, 2장 순서 선택 | 선택한2장만 버림, 마지막 선택 top, 다음 생존자 |R07|
| A07 | 손패가 HP 이하에서 임의 버리기 | 거절, 동일 상태 |R07|
| A08 | 6명중 B,C 탈락; A가 D 공격 | 생존원 A,D,E,F 기준 최단거리 사용 |R10|
| A09 | A Rose+Scope, B Paul+Mustang | 기본거리+2−2, 최소1; 역방향 별도 계산 |R10|
| A10 | A Winchester, B까지 거리2에서 Panic | 거절; BANG은 거리≤5면 허용 |R11,R18|
| A11 | 덱1장, Stagecoach 사용 | 1장 뽑고 사용한 Stagecoach 포함 discard 재셔플 후 두 번째 뽑음 |R08|
| A12 | 덱0, discard 존재, Pedro 첫 카드 선택 | discard top 먼저 가져오거나 재셔플 후 덱 선택 가능 |R08,C10|
| A13 | 덱·discard0, 뽑기 필요 | 카드를 생성하지 않고 resource-exhausted 일시정지 |D05|
| A14 | Draw!에서 Beer 공개 | HP 변화 없음, 카드 손패로 안 감, discard로 이동 |R09|
| A15 | 동일 seed/fixture/commands 반복 | 동일 최종state/events, RNG state까지 재현 |불변조건|

## B. 22종 카드와 반응

| ID | Given / When | Then | 규칙 |
|---|---|---|---|
| B01 | 정상 A가 첫 BANG B에게; B Missed | 피해0, BANG count1, 두 카드 discard |R12–13|
| B02 | 같은 턴 두 번째 일반 BANG | 거절; 효과 없는 입력이 quota 증가시키지 않음 |R12|
| B03 | Volcanic으로 BANG2회 후 다른 무기 교체 | 추가 일반 BANG 거절, count 유지 |R12,R26|
| B04 | 사거리밖 BANG/자기 BANG/죽은 대상 | 모두 거절, 카드 안 버림 |R10–12|
| B05 | Barrel Heart/비Heart 두 fixture | Heart는 방어1; 실패면 Missed 또는 피해 선택 가능 |R13,R22|
| B06 | Slab BANG에 Barrel 성공 + Missed1 | 방어 성공; Barrel만 성공이면 아직 방어1 필요 |R13,C13|
| B07 | Slab BANG에 Missed1 쓰고 포기 | Missed는 소비, 피해1 |R13|
| B08 | Gatling 사용한 A가 이어 BANG 사용 | Gatling이 quota 소모 안 함, BANG 허용 |R19|
| B09 | Slab Gatling에 B Missed1 | 정상 방어 완료 |R19,C13|
| B10 | Indians 대상이 BANG 제출/포기 | 제출시피해0, 포기시피해1; Barrel/Missed 불가 |R20|
| B11 | Duel A→B | B 먼저 BANG, A,B 교대; 포기한 쪽 피해1, quota 변화없음 |R21|
| B12 | Calamity가 Indians/Duel에 Missed 제출 | BANG 변환 대응 허용 |C03|
| B13 | Calamity 자기턴 Missed로 공격 | BANG count1 증가, 대상 일반 방어 가능 |C03|
| B14 | HP만피 또는 생존자2명, 자기턴 Beer | 사용/버림은 가능, 회복0 |R14|
| B15 | 자기턴 HP2/max4에서 Beer | HP3, 다른 플레이어 회복 불가 |R14|
| B16 | 생존자2명 Saloon | 둘 다 max까지1회복; 죽은 좌석 부활 없음 |R15|
| B17 | Duel 치명상에 Saloon 사용 요청 | 구제 불가, 카드 소비 안 됨 |R15,R27|
| B18 | General Store, 생존5 | 정확히5 공개, 사용자부터5명이1장씩, 중복선택불가 |R17|
| B19 | Panic 상대 손패 선택 | 서버 RNG1장, 남의 hidden ID를 클라이언트에서 고르지 않음 |R18|
| B20 | Cat 상대 장착 선택 | 지정 카드 discard, 손패는 안 바뀜 |R18|
| B21 | 자기 Mustang에 Panic/Cat | Panic이면손패, Cat이면discard; 자기손패 대상은 거절 |D03|
| B22 | Stagecoach/Wells 사용 | 각각2/3 뽑기, 획득 face는 자기만 공개 |R16|
| B23 | 동일명 파란 카드 이미 장착 | 두 번째 동일명 사용 거절; 무기 다른명 교체는 기존 버림 |R06|
| B24 | Jail 보안관/자신 대상으로 사용 | 거절; 거리 먼 일반 상대는 허용 |R23|
| B25 | Jail 판정 Heart/비Heart | Jail은 항상 discard top; Heart 정상draw, 실패 전체턴skip |R23|
| B26 | 감옥 붙은 상대가 공격받음 | Barrel/Mustang 유효, 방어 입력 가능 |R23|
| B27 | Dynamite 판정 Spade2,9,10,A 각각 |2/9 폭발피해3,10/A 전달 |R24|
| B28 | Dynamite+Jail 함께 있는 턴 | Dynamite 먼저, 생존하면 Jail, 죽으면 Jail 판정 안 함 |R05,R24|
| B29 | Dynamite 비폭발, 다음 좌석 사망 | 다음 생존자에게 이동, 새 카드 생성 없음 |R24|
| B30 | 무기 없는 상대 기본 총에 Cat 요청 | 실물 카드가 아니므로 거절 |R11|

## C. 인물 능력·치명상·승리

| ID | Given / When | Then | 규칙 |
|---|---|---|---|
| C01 | Bart HP4 Dynamite3피해 | HP1 후 덱3획득 |C01|
| C02 | Bart HP1 BANG, 손패Beer0, topBeer | 능력 뽑기로 구제 못함, 탈락 |C01,R27|
| C03 | Bart HP1 BANG, 기존Beer1 | Beer구제 후 Bart1장 획득 |C01,R27|
| C04 | Black Jack 두번째 red/black | red추가1, black추가0; 두번째만 공개 |C02|
| C05 | El Gringo가 자신의 Duel에서 패배 | HP−1, 상대손패 탈취없음 |C04|
| C06 | El Gringo 상대 공격 생존/상대손패0 | HP감소, 빈 손패에서 생성/탈취없음 |C04|
| C07 | Jesse 첫뽑기 상대 손패 선택 | 서버 무작위1탈취, 두번째deck; 상대빈손 선택불가 |C05|
| C08 | Jourdonnais+Barrel, Slab공격, 둘다Heart | 판정2회로 방어2완료; 같은원천 재사용불가 |C06,C13|
| C09 | Kit top3 [X,Y,Z], X,Z선택 | 자기손패 X,Z; 덱top Y; 다른사용자는 셋face 모름 |C07|
| C10 | Lucky Jail 판정2장 Heart/Spade | Lucky가 선택한 카드만 판정에 사용, 둘다discard, Jail마지막 |C08,D04|
| C11 | Paul/Mustang 또는 Rose/Scope | 각각중첩2, 거리최소1 |C09,C11|
| C12 | Pedro discard첫카드 선택 | 해당top손패, 다음deck1; discard전체열람불가 |C10|
| C13 | Sid 자기턴 hand4 HP2/max4, 두번 비용 | 정확히4장 버려HP4, 임의장착카드 비용불가 |C12|
| C14 | Sid 다른카드 해결도중 비치명상 회복 | 거절; 자기 치명상 창에서만 예외 허용 |C12,D02|
| C15 | 생존자2명 Sid hand2 HP1에 피해1 | 비용2로HP1 생존; Beer 구제는무효 |D02|
| C16 | Suzy 마지막 General Store/Stagecoach/Wells Fargo 각각사용 | 각각 효과로1/2/3장획득, 능력추가뽑기0 |C14|
| C17 | Suzy 마지막 Duel 사용/응답 | Duel 끝날때까지 능력대기; 아직살아있고 손패0이면1 |C14|
| C18 | Suzy 손패Missed1, Slab공격, topMissed | 첫Missed후뽑아 두번째Missed대응 가능, 다시손패0이면뽑기 |C14|
| C19 | Suzy 마지막BANG→El Gringo 생존피해 | Suzy뽑기→Gringo탈취→Suzy다시뽑기 |C04,C14|
| C20 | Vulture생존, 다른플레이어탈락 | 손패+장착모두 Vulture손패, 장착효과자동적용없음 |C15|
| C21 | 폭발로탈락, Vulture생존 | Dynamite는회수안됨 |C15,R24|
| C22 | Sheriff Vulture가 Deputy처치 | 부관카드회수후 자신의카드까지 전부버림 |C15,R28|
| C23 | Willy가 BANG3회, 세번째사거리밖 | 첫2합법, 세번째거리오류 |C16|
| C24 | HP2 Dynamite3피해, Beer2 | 순서대로회복하여HP1; Beer1만쓰고포기면탈락 |R27|
| C25 | Outlaw가 Duel개시후자신탈락 | 상대가무법자보상3장 못받음 |R28|
| C26 | 다른플레이어가 Outlaw를 BANG처치 | 책임자가3장, 사망정리후 source변경없음 |R28|
| C27 | Dynamite로 Outlaw탈락 | 아무도처치보상없음 |R28|
| C28 | 탈락자손패2+장착1, Sam없음 | 본인이버림순서선택, 일반게임입력은거절 |R07,R28|
| C29 | Renegade Gatling로 Sheriff포함 나머지전멸 | 모든대상해결후 Renegade승리, 중간종료안함 |R29–30|
| C30 | Sheriff사망, 다른생존자2이상 | Outlaw진영승리, 이미죽은Outlaw도승리표시 |R30|
| C31 | Sheriff생존, 마지막Outlaw/Renegade탈락 | Sheriff+Deputy승리, 사망Deputy도공동승리 |R30|
| C32 | 종료후 PLAY_CARD | 거절, 역할전체공개/생존손패비공개 |R30,D08|

## D. 서버·클라이언트·운영

| ID | 조작 | 기대 결과 / 증거 |
|---|---|---|
| D01 | 같은commandId/payload 2회, 첫ACK 유실 | 원래receipt 재전송, 카드/HP/보상/version 1회만 변화 |
| D02 | 같은commandId에 다른payload | COMMAND_ID_REUSED, 변화없음 |
| D03 | 같은version에 동시 정상명령2개 | 하나만커밋, 다른쪽STALE_VERSION; 룰이중실행없음 |
| D04 | JSON에 actorId 또는 남의cardId 삽입 | strict validation/소유권검사 거절 |
| D05 | 남의match sync/임의socket room join 시도 | 존재/비공개내용노출없이거절 |
| D06 | 진행중모든플레이어 snapshot·ACK·오류·웹소켓frame 점검 | 다른손패face/ID·역할·덱순서·seed없음; legalActions로 숨은카드 추론불가 |
| D07 | 상대손패 임의선택 UI/서버 요청 | zone선택만허용, 서버무작위; opponent cardId 목록안내려옴 |
| D08 | Duel/구제/Lucky/버림순서/전체공격 cursor에서서버재시작 | 정확한pending·HP·카드·책임자·입력권 복구 |
| D09 | DBcommit전장애/commit후ACK전장애 | 전자는롤백, 후자는receipt재응답; outbox유실효과없음 |
| D10 | socket재접속, 브라우저새로고침, 같은세션두탭 | 같은좌석복구; 중복행동은version/receipt제어 |
| D11 | 비참가자/탈락자/방장 게임중kick 입력 | 권한대로거절; 탈락자 자기정리pending만예외 |
| D12 | 한참응답하지않거나연결끊음 | 타이머OFF이므로자동패스/탈락없음, 상태보존안내 |
| D13 | 모바일360px/데스크톱, 키보드만사용 | 대상·방어·구제·순서선택 가능, 포커스명확, 확대카드닫기가능 |
| D14 | 동일타입 다른rank/suit 80장 렌더 | 인스턴스값과표시일치, 원본인쇄값겹침없음; 2장의Stagecoach9Spade는구별ID |
| D15 | 이미지누락/지연 | 텍스트이름+rank/suit+효과가독, 선택막히지않음 |
| D16 | 3명/8명으로시작 또는누군가미준비 | 시작거절; 4~7전원준비만허용 |
| D17 | 초대코드추측폭주/긴표시명/HTML표시명 | rate limit/길이제한/텍스트이스케이프, 서버stack안노출 |
| D18 | 종료후다시시작 | 새matchId, 새덱/역할/seed, 이전secret재사용없음 |
| D19 | 전체기본판한게임 4인 및7인 | 준비→시작→턴→대응→탈락→결과→재대기실 증거; 적어도한번재접속 포함 |
| D20 | 카드이동·재셔플·탈락·보상 매단계 | 카드80장보존, 중복소유0, 음수handCount0, pending담당자유효 |

## 완료 보고 양식

`케이스 ID / 구현 파일 / 실행 명령 / 실제 결과 / 실패 로그 위치 / 재현 seed / 미검증 이유`를 기록한다. UI 사진만으로 서버 비밀성이나 멱등성을 통과 처리하지 않는다. 정적 코드 검토만 수행한 항목은 실행 통과와 구별한다. D05 자원고갈 정책과 D03 자기손패 대상 정책은 공식 판정 증명 대신 선택한 ruleset 계약의 일관성을 검사한다.
