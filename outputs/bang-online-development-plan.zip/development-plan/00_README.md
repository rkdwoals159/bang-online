# BANG! 온라인 기본판 — 개발 준비 패키지

2026-09-27 · 상태: **기능·규칙·개발 계획 작성 완료, 게임 구현은 아직 시작하지 않음**.

## 목표

친구 4~7명이 초대 링크로 들어와 한국어 기본판 BANG! 한 판을 시작하고, 모든 카드·인물·승리 조건을 서버 판정으로 진행하며, 연결이 끊겨도 같은 자리로 돌아오는 무료 웹사이트를 만든다. 현재 준비물은 구현을 작게 나누고 서로 다른 에이전트의 코드가 같은 계약으로 합쳐지게 하는 문서와 데이터다.

### 고정 범위

- 기본판 80장 / 플레이 카드22종 / 인물16명 / 역할4종.
- 게스트 이름, 비공개 초대방, 준비 및 시작, 개인 손패/역할, 전체 카드 효과와 응답, 탈락 및 결과, 재접속.
- 한국어 이미지42종 활용. 카드마다 달라지는 숫자·무늬는 80장 카탈로그에서 가져온다.
- 서버 권위, DB 저장, 중복 명령 방지, 플레이어별 비공개 정보 필터링.
- 타이머 OFF. 진행 중 강제퇴장과 자동 탈락 없음.

AI 상대, 확장판, 공개 매칭, 계정·랭킹·결제, 채팅·음성 기능은 첫 릴리스에서 제외한다. 대화는 외부 음성 서비스 등을 사용한다. 무료 이용 서비스라도 서버/DB 호스팅 비용은 별도 운영 비용이다.

## 읽는 순서

| 문서 | 쓰임 |
|---|---|
| [01_RULES.md](01_RULES.md) | 공식 출처, 게임 규칙 R01–30, 인물 C01–16, 명시적 구현 결정 D01–08 |
| [02_PRODUCT_UX.md](02_PRODUCT_UX.md) | 화면·입력·오류·모바일·에셋 요구사항 |
| [03_ARCHITECTURE.md](03_ARCHITECTURE.md) | 패키지 경계, 순수 엔진, 영속 상태, 세션·보안 |
| [04_PROTOCOL.md](04_PROTOCOL.md) | 명령·응답·버전·멱등성·동기화 계약 |
| [05_EXECUTION_PLAN.md](05_EXECUTION_PLAN.md) | T01~T60 작업, 의존성, 파일 소유권, 완료 기준 |
| [06_ACCEPTANCE_TESTS.md](06_ACCEPTANCE_TESTS.md) | 97개 Given/When/Then 수락 시나리오 명세 |
| [07_READINESS.md](07_READINESS.md) | 결정 기록, 출시 전 운영 체크, 남은 작업 구분 |
| [prompts/ORCHESTRATOR.md](prompts/ORCHESTRATOR.md) | 루트 에이전트의 배정·통합·리뷰 절차 |
| [prompts/AGENT_TASK_TEMPLATE.md](prompts/AGENT_TASK_TEMPLATE.md) | 작업자에게 한 작업씩 전달하는 프롬프트 |

## 바로 쓸 데이터

| 파일 | 내용 |
|---|---|
| [data/base-deck.json](data/base-deck.json) / [CSV](data/base-deck.csv) | 개별80장, 고유 definitionId, typeId, rank, suit, copyIndex |
| [data/card-types.json](data/card-types.json) | 22종, 수량, 색상, 한국어 에셋 경로 |
| [data/characters.json](data/characters.json) | 16명, 기본HP, 규칙ID, 에셋 경로 |
| [data/roles.json](data/roles.json) | 역할 및 4~7인 배분 |
| [data/catalog-summary.json](data/catalog-summary.json) | 사용 주의점과 수량 요약 |
| [data/sources.json](data/sources.json) | 공식 출처 URL·확인일·원본 SHA-256 |
| [data/task-index.csv](data/task-index.csv) | 60개 작업의 의존성·소유 경로·수락 기준과 TODO 상태 |

`assetPath`는 이 문서가 있는 development-plan 폴더 기준이다. 실제 앱에 복사할 때 T05/T54가 public URL로 변환한다. `definitionId`는 공개 카탈로그의 항목 키다. 숨긴 실제 카드의 `cardInstanceId`로 쓰면 카드 종류가 노출되므로 매치 시작 때 별도 불투명 ID를 생성한다. Stagecoach 두 장은 **둘 다 Spade9**이며 숫자·무늬 조합을 unique key로 쓰면 안 된다.

## Luna max 병렬 개발 운영

이 준비 문서 작성에도 Luna max 작업자3명을 사용해 UX·아키텍처·작업 계획을 병렬 작성하고 루트에서 규칙·데이터·수락 기준을 통합했다. 모델이 한 번에 전체 게임을 완벽히 구현한다고 전제하지 않는다.

1. 루트1명 + 작업자최대3명. 한 작업자는 한 번에 T-ID 하나만 맡는다.
2. 처음 T01 저장소, T02 프로토콜, T03 카탈로그 스키마를 고정한다. 의존 작업을 먼저 달리지 않는다.
3. 공용 상태·reducer·효과 API를 고정한 후 카드/인물 모듈을 병렬화한다.
4. 작업 패킷은 관련 규칙 절, 고정 DTO, 허용 경로, 수락 케이스만 담는다. 전체 규칙을 매번 재해석하게 하지 않는다.
5. 구현 에이전트의 완료 주장 뒤 루트가 diff·계약·증거를 검토한다. REVIEW 상태를 DONE과 혼동하지 않는다.
6. 막힌 규칙이나 공용 API 변경은 독단 해결하지 않고 루트에 제안한다. 다른 독립 작업은 계속한다.

### 개발 시작용 프롬프트

```text
outputs/development-plan/00_README.md와 prompts/ORCHESTRATOR.md를 기준으로
BANG! 기본판 온라인 게임을 구현해주세요.
작업자는 gpt-6-luna, reasoning effort max로, 동시 최대3명 사용하세요.
먼저 T01을 완료하고 의존성이 DONE인 작업만 한 번에 하나씩 배정하세요.
공용 계약은 단독 소유자로 관리하고, 05_EXECUTION_PLAN의 파일 소유권을 지키세요.
01_RULES의 공식 규칙과 명시적 구현 결정을 적용하고 새 규칙을 추측하지 마세요.
06_ACCEPTANCE_TESTS를 기준으로 구현 테스트를 작성·실행하여 검증해주세요.
97개 수락 케이스의 미검증 항목을 통과로 기록하지 마세요.
로컬에서 전체 흐름을 완성하고 결과를 보고해주세요. 외부 배포는 별도 단계입니다.
```

## 근거와 한계

기준은 [공식 4판 규칙서](https://www.dvgiochi.com/giochi/bang/download/Bang_rules_ENG.pdf), [공식 FAQ](https://www.dvgiochi.com/giochi/bang/download/Bang!_FAQ_ENG.pdf), [공식 카드 목록](https://bang.dvgiochi.com/cardslist.php?id=1&lang=en)이다. 최신 [공식 대회 문서](https://www.dvgiochi.com/bang_champ/MaterialeCampionato/BANG!%20Campionato%20nazionale_Regolamento-daTorneo.pdf)의 **일반 기본판 FAQ만** 보충 적용한다. 대회 변형 규칙은 제외했다.

공식 문서가 온라인 순서까지 정하지 않는 항목은 01_RULES §8에 제품 결정으로 표시했다. 특히 Sid의 상세 타이밍과 자기 Panic/Cat 대상 범위를 공식 인용과 구분했다. 현재 게임 코드·실행 테스트·배포는 수행하지 않았다. 문서와 데이터가 준비됐다는 사실은 게임 구현 검증이 끝났다는 뜻이 아니다.
