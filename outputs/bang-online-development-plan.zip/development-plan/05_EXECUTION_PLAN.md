# 05. 실행 계획 및 작업 명세

## 목적과 실행 전제

이 문서는 뱅! 기본판 한국어 온라인 웹게임의 미래 구현을 위해 작업을 나누고, 각 작업의 파일 소유권과 완료 기준을 고정한다. 현재 문서 작성 시점에는 코드와 테스트가 만들어지지 않았으며 아래 60개 작업 상태는 모두 TODO다.

구현 저장소 경로는 미래 오케스트레이터가 작업 시작 시 지정한다. 아래 파일 소유권은 저장소 루트 기준 상대 경로다. 권장 구조는 다음과 같다.

- apps/web: React + Vite 브라우저 클라이언트
- apps/server: Node.js + Socket.IO 실시간 서버
- packages/engine: I/O 없는 순수 TypeScript 게임 엔진
- packages/contracts: 클라이언트와 서버 사이의 공유 프로토콜 계약
- packages/catalog: 카드, 역할, 인물, 이미지 매핑 데이터
- packages/test-fixtures: 프로토콜과 엔진의 결정적 테스트 입력

세부 프레임워크 설정, 저장소 방식, 배포 방식은 03_ARCHITECTURE.md가 정한다. 프로토콜 필드와 이벤트 의미는 04_PROTOCOL.md가 정한다. 작업자는 이 문서에서 스택 결정을 추측해 새 기술 의존성을 추가하지 않는다.

모든 작업자는 다음 자료를 읽고 적용한다.

1. 00_README.md
2. 01_RULES.md
3. 02_PRODUCT_UX.md
4. 03_ARCHITECTURE.md
5. 04_PROTOCOL.md
6. 05_EXECUTION_PLAN.md의 할당 작업과 완료된 의존 작업만
7. 06_ACCEPTANCE_TESTS.md
8. 07_READINESS.md
9. 카드 이미지 또는 카드 수량을 다루는 경우 outputs/assets/ASSET_INVENTORY.md, outputs/assets/asset_manifest.csv, outputs/assets/ATTRIBUTION.md

01_RULES.md는 공식 게임 규칙에 대한 권위 문서다. 해석이 불분명하거나 문서 사이에서 규칙이 충돌하면 임의로 규칙을 정하거나 구현하지 말고, 작업을 막는 정확한 근거와 질문을 오케스트레이터에게 보고한다. 규칙 변경은 루트 담당자가 확인한 출처를 바탕으로 01_RULES.md를 갱신한 뒤에만 반영한다.

초기 범위는 기본판, 비공개 초대방, 게스트 참가, 서버 권위 게임 진행, 재접속 복구다. AI 상대, 확장판, 공개 매칭, 랭킹, 자동 턴 제한 시간은 범위에 없다. 시간 만료는 기본 OFF다.

## 공통 품질 및 소유권 규칙

- 작업 하나는 에이전트 하나가 맡는다. 한 에이전트가 동시에 여러 작업을 소유하지 않는다. 작업을 더 작은 하위 작업으로 재위임하지 않는다.
- 작업자는 명시된 소유 경로만 수정한다. 공유 파일을 바꾸어야 하면 직접 충돌을 만들지 말고 오케스트레이터에게 변경 제안과 이유를 보낸다.
- packages/contracts의 공유 프로토콜 타입은 T02의 담당자가 소유하고, 공용 엔진 상태·reducer·효과 인터페이스는 각각 해당 작업 담당자만 수정한다. 이 파일들은 병렬 작업 중 임의로 고치지 않는다.
- 카드별 규칙 구현은 개별 카드 효과 모듈 경로를 나누어 병렬화한다. 한 카드 모듈은 하나의 작업만 소유한다. 공용 reducer, 공용 상태 타입, 효과 API, 등록기 수정은 개별 카드 작업에 포함되지 않는다.
- 셔플은 외부에서 주입되는 RNG 인터페이스만 사용한다. 게임 로직에서 Math.random, 벽시계 또는 네트워크 순서에 기대지 않는다.
- 모든 플레이어에게 전달되는 공개 상태와 본인만 읽는 비공개 상태를 분리한다. 변경 알림은 버전 무효화 정보만 보내고, 서버는 인증된 sync 요청마다 플레이어별 projection을 생성한다.
- 게임 명령에는 프로토콜에 정의된 expectedVersion과 idempotency 식별자를 적용한다. 같은 명령의 재전송은 중복 상태 변경을 만들지 않는다.
- 연결 끊김 후에는 저장된 게임 상태와 플레이어별 비공개 정보를 복구해 올바른 클라이언트 projection으로 다시 보낸다.
- 향후 수락 기준의 테스트 파일은 계획된 산출물이다. 이번 계획 작성에서는 코드나 테스트를 만들거나 실행하지 않았다.
- 상태 관리자는 실행을 시작하기 전까지 모든 작업을 TODO로 유지한다. TODO, IN_PROGRESS, BLOCKED, REVIEW, DONE은 미래 추적용 상태 어휘이며 이 문서의 현재 작업 상태는 전부 TODO다.

## 실행 파동과 통합 게이트

의존성 그래프가 우선이며 파동 번호는 권장 착수 순서다. 독립 작업은 앞선 파동과 겹쳐 실행할 수 있지만 선행 작업의 산출물 계약이 고정되기 전에 종속 파일을 만들지 않는다.

| 파동 | 작업 | 목적 및 통과 기준 |
|---|---|---|
| W0 문서 기준선 | 작업 전 게이트 G0 | 00~07 문서와 준비 데이터가 존재하고 상호 모순을 검토한다. 공식 규칙 질문이 있으면 루트 담당자가 판정하기 전까지 해당 규칙에 의존하는 작업을 BLOCKED로 둔다. |
| W1 저장소와 계약 | T01~T05 | G1: 워크스페이스가 설치 가능하고 공유 프로토콜, 카탈로그 스키마, 기본 데이터 형태가 04_PROTOCOL.md 및 03_ARCHITECTURE.md와 일치한다. |
| W2 엔진 공용 기반 | T06~T15 | G2: 순수 엔진에서 결정적인 초기화, 턴 reducer, 합법성 검사, 해결 파이프라인, 게임 종료 규칙 및 효과 API가 고정된다. 공용 reducer/state/protocol 변경은 오케스트레이터가 조정한다. |
| W3 효과 모듈 | T16~T40 | 서로 독립적인 카드 모듈을 병렬 작성한다. G3: 모듈별 수락 기준을 통과하고 각 변경이 지정된 파일 경로에만 한정된다. |
| W4 엔진 등록 및 검증 | T41~T42 | G4: 개별 효과가 한 등록 경로로 조립되고, 엔진 시나리오가 정해진 입력에서 결정적으로 통과한다. |
| W5 서버 | T43~T49 | 일부 저장소/방 서비스 작업은 W2 이후 병행 가능하다. G5: 초대방, 명령 권한 검사, 비공개 projection, 재접속 복구를 서버 통합 기준으로 확인한다. |
| W6 웹 클라이언트 | T50~T59 | 셸 작업은 W1 뒤에 시작할 수 있다. 나머지는 계약, fixture 또는 서버 API에 맞춰 진행한다. G6: 로비부터 재접속까지 브라우저 경로와 접근성 기준이 연결된다. |
| W7 전체 검수 | T60 | G7: 승인된 로컬 실행 환경에서 초대 게스트들이 게임을 끝까지 진행하고 재접속하는 수락 흐름이 증거와 함께 확인된다. |

## 병렬 실행 계획

현재 동시성 가정은 총 4 슬롯이며, 오케스트레이터 1명과 작업자 최대 3명으로 계산한다. 실제 실행 환경의 동시성 제한이나 충돌 위험에 따라 오케스트레이터가 작업자 수를 낮춘다. 이는 용량 계획일 뿐 특정 모델의 속도, 성능 또는 토큰 크기를 보장하지 않는다.

작업 큐는 준비된 의존성 중에서 다음 우선순위로 채운다.

1. 한 번에 하나의 작업만 각 작업자에게 전달한다.
2. 세 작업자에게 서로 겹치지 않는 파일 소유권 작업을 우선 배정한다.
3. T16~T40의 카드 효과는 T15가 고정된 뒤 파일 단위로 나눠 배정한다. 공용 카드 이벤트 모델을 고쳐야 한다고 판단되면 해당 카드 작업을 멈추고 오케스트레이터가 공용 변경을 별도 처리한다.
4. 여러 작업자가 공용 계약 또는 엔진 공용 파일을 수정해야 하는 상황은 허용하지 않는다. 계약 또는 reducer 변경은 단일 소유 작업으로 합친 뒤 소비자 작업을 재개한다.
5. 완료 산출물은 통합 게이트를 통과하기 전까지 후속 작업의 기준 버전으로 간주하지 않는다.

## 중요 경로

기본적인 플레이 가능한 경로는 G0 → T01 → T02/T03/T04/T05 → T06/T08 → T09 → T10/T11/T12/T13 → T14/T15 → 카드 모듈(T16~T40) → T41/T42 → T43/T44/T45/T46/T47/T48 → T58 → T60 순서다. UI는 계약 T02와 게임 projection T07을 이용해 일부 서버 작업과 겹쳐 진행할 수 있다. 재접속/비공개 상태 검증 T48 및 웹 동기화 T58은 통합 검수 전에 생략할 수 없다.

## 작업 명세

각 작업은 단일 파일 소유권을 갖고, 산출물은 변경 파일과 acceptance 증거다. 아래 입력 목록은 공통 입력 문서에 추가되는 해당 작업의 직접 입력이다. 작업 ID, 상태, 파동, 의존성, 소유 경로, 수락 기준의 CSV 색인은 [data/task-index.csv](data/task-index.csv)에 있다.

### W1 — 저장소와 계약

#### T01 — 모노레포 기본 뼈대

- 상태: TODO
- 의존: 없음
- 파일 소유: 루트 package.json, pnpm-workspace.yaml, 공통 package manager lockfile, 루트 tsconfig.json, 각 apps/packages의 최소 package manifest
- 입력: 03_ARCHITECTURE.md
- 범위: 위 여섯 영역의 workspace 연결과 공통 개발 명령 진입점을 만든다.
- 제외: 앱 기능, 프로토콜 필드, CI 배포 파이프라인
- 산출물: 의존성 설치와 각 패키지 작업 진입점이 정의된 워크스페이스
- 수락 기준: 깨끗한 checkout에서 문서화한 설치 명령이 성공한다. 각 앱/패키지 manifest가 workspace에 포함되고, 앱 코드를 아직 요구하지 않는 공통 검사 명령이 실패 없이 종료한다.

#### T02 — 공유 프로토콜 계약과 기본 fixture

- 상태: TODO
- 의존: T01
- 파일 소유: packages/contracts/**, packages/test-fixtures/protocol/**
- 입력: 04_PROTOCOL.md
- 범위: 버전이 붙은 이벤트/명령/응답/상태 DTO, expectedVersion, idempotency key, fixture 직렬화 예제를 정의한다.
- 제외: 서버 라우팅, 엔진 상태 전이, UI 컴포넌트
- 산출물: 계약 타입 및 유효한 프로토콜 샘플과 잘못된 샘플
- 수락 기준: 각 문서화 이벤트의 최소 유효 fixture가 타입 검사를 통과한다. 누락된 버전 또는 필수 필드가 포함된 fixture는 검증에서 거부된다. 비공개 역할/손패 필드는 공개 응답 타입에 존재하지 않는다.

#### T03 — 카탈로그 스키마

- 상태: TODO
- 의존: T01, T02
- 파일 소유: packages/catalog/src/schema.ts, packages/catalog/src/validate.ts, packages/catalog/test/schema.test.ts
- 입력: 01_RULES.md, 03_ARCHITECTURE.md, 04_PROTOCOL.md, outputs/assets/asset_manifest.csv
- 범위: 카드 정의, 물리 덱 수량, 역할, 인물, 에셋 참조 데이터의 필드와 정적 검증 규칙을 정의한다.
- 제외: 실제 효과 실행, 이미지 수정, 규칙 문구 재해석
- 산출물: 카탈로그 자료형과 입력 데이터 검증 함수
- 수락 기준: 유효/무효 카탈로그 fixture 각각이 스키마 검사에서 올바르게 승인/거부된다. 식별자 중복, 알 수 없는 에셋 경로, 음수 수량은 거부된다.

#### T04 — 기본 덱 데이터 가져오기 및 검증

- 상태: TODO
- 의존: T03
- 파일 소유: packages/catalog/src/cards/**, packages/catalog/test/cards.test.ts
- 입력: 01_RULES.md, outputs/development-plan/data/base-deck.json, outputs/development-plan/data/base-deck.csv, outputs/development-plan/data/card-types.json, outputs/assets/asset_manifest.csv
- 범위: 이미 준비된 기계용 덱/카드 정의를 packages/catalog로 가져오고 스키마를 검증한다. 원본 데이터는 수량과 정확한 rank/suit의 기준이다.
- 제외: 카드 데이터 수작업 재수집/재입력, 카드 효과 구현, 출처 이미지 재가공
- 산출물: 기본 덱 카탈로그 어댑터/데이터와 원본 대조 테스트
- 수락 기준: 테스트가 소스 JSON에 기록된 80개 인스턴스, 22개 카드 종류, 수량, rank, suit를 모두 대조한다. 두 소스가 다르면 하나를 추측해 고치지 않고 차이를 보고한다. 카드 정의의 에셋 키가 inventory에 존재한다.

#### T05 — 역할·인물 데이터 가져오기와 에셋 경로

- 상태: TODO
- 의존: T03
- 파일 소유: packages/catalog/src/roles/**, packages/catalog/src/characters/**, packages/catalog/src/assets/**, packages/catalog/test/roster-assets.test.ts
- 입력: 01_RULES.md, outputs/development-plan/data/roles.json, outputs/development-plan/data/characters.json, outputs/assets/asset_manifest.csv, outputs/assets/ASSET_INVENTORY.md, outputs/assets/ATTRIBUTION.md
- 범위: 이미 준비된 역할/인물 자료를 스키마로 가져오고 실제 웹 공개 경로에 맞춰 에셋 ID와 파일 URL을 연결한다. 파일 URL은 apps/web/public/assets/cards/ 아래를 기준으로 한다.
- 제외: 인물 능력 코드, 역할/인물 데이터 수작업 재수집, 권리 범위 확대, 카드 이미지 편집
- 산출물: 역할/인물 카탈로그 및 public asset URL/출처 메타데이터
- 수락 기준: 테스트가 원본 JSON의 7개 역할 카드와 16개 인물의 ID/정적 필드를 대조한다. 모든 이미지 URL이 T54에서 복사할 실제 파일명과 일치하고 attribution metadata가 보존된다. 규칙 의미 불일치는 임의 보정하지 않고 질문으로 등록한다.

### W2 — 엔진 공용 기반

#### T06 — 엔진 상태 모델

- 상태: TODO
- 의존: T02, T03
- 파일 소유: packages/engine/src/state/types.ts
- 입력: 01_RULES.md, 03_ARCHITECTURE.md, 04_PROTOCOL.md
- 범위: 게임 내부 상태의 덱/버림/플레이어/턴/대기 중인 해결 단계 자료형을 정의한다.
- 제외: 상태 전이 함수, 네트워크 DTO 중복 선언
- 산출물: 직렬화 가능한 내부 GameState 및 불변식 타입
- 수락 기준: 정상 플레이 상태와 대기 중인 반응 상태를 모두 표현한다. 공개 DTO와 비공개 정보의 경계가 타입으로 구분되고, 프로토콜 DTO를 복사해 중복 정의하지 않는다.

#### T07 — 플레이어별 공개 상태 projection

- 상태: TODO
- 의존: T02, T06
- 파일 소유: packages/engine/src/state/projection.ts, packages/engine/test/state/projection.test.ts
- 입력: 01_RULES.md, 04_PROTOCOL.md, 06_ACCEPTANCE_TESTS.md
- 범위: 내부 상태와 관전자 자격이 아닌 지정 좌석 정보를 받아 해당 플레이어가 볼 수 있는 상태를 계산한다.
- 제외: Socket.IO 전송, 임의의 추가 정보 노출, 로그인
- 산출물: 순수한 player-specific projection 함수
- 수락 기준: 두 플레이어의 손패/역할 비공개 필드가 서로의 projection에 나타나지 않는다. 공개 상태(버림 더미, 장착, 생명력 등)는 모든 플레이어 projection에서 같은 버전으로 일치한다. projection 호출은 상태를 변경하지 않는다.

#### T08 — 주입형 RNG와 덱 셔플

- 상태: TODO
- 의존: T06
- 파일 소유: packages/engine/src/random/**, packages/engine/test/random/**
- 입력: 03_ARCHITECTURE.md, 06_ACCEPTANCE_TESTS.md
- 범위: 엔진 생성 시 전달할 RNG 계약과 덱 셔플을 구현한다.
- 제외: 전역 RNG, 방 생성, 외부 난수 서비스
- 산출물: 주입형 결정적 난수 인터페이스와 셔플 함수
- 수락 기준: 동일한 고정 RNG 시퀀스와 같은 덱에서 동일한 결과가 나온다. 원소 수와 카드 식별자가 셔플 전후 보존된다. 구현은 Math.random과 시스템 시간에 접근하지 않는다.

#### T09 — 게임 초기화

- 상태: TODO
- 의존: T04, T05, T06, T08
- 파일 소유: packages/engine/src/setup/**, packages/engine/test/setup/**
- 입력: 01_RULES.md, 06_ACCEPTANCE_TESTS.md
- 범위: 인원수와 시드가 주어졌을 때 역할/인물/초기 손패/체력/턴/덱을 규칙에 따라 배정한다.
- 제외: 룸 로비, 네트워크 메시지
- 산출물: 초기 GameState 생성기와 재현 가능한 fixture
- 수락 기준: 허용 인원수 경계에서 역할별 장수, 보안관 첫 차례, 초기 체력 및 카드 수가 01_RULES.md와 일치한다. 고정 RNG를 사용한 초기화가 재현 가능하다.

#### T10 — 턴 상태 reducer

- 상태: TODO
- 의존: T06, T09
- 파일 소유: packages/engine/src/turn/**, packages/engine/test/turn/**
- 입력: 01_RULES.md, 04_PROTOCOL.md
- 범위: 단계 진입/종료, 현재 차례 전환, 필수 단계의 진행을 순수 reducer로 구현한다.
- 제외: 개별 카드 효과, Socket.IO 시간/이벤트
- 산출물: 엔진 공용 reducer와 상태 전이 결과 타입
- 수락 기준: 허용되지 않은 단계 전이가 명시적 오류를 낸다. 합법 전이는 버전과 현재 좌석을 갱신하며 상태 불변식을 유지한다. 같은 입력 상태/행동/난수에 같은 결과가 나온다.

#### T11 — 합법 행동, 거리 및 대상 계산

- 상태: TODO
- 의존: T06, T10
- 파일 소유: packages/engine/src/rules/legality.ts, packages/engine/src/rules/distance.ts, packages/engine/test/rules/**
- 입력: 01_RULES.md, 06_ACCEPTANCE_TESTS.md
- 범위: 현재 상태에서 가능한 행동/대상, 좌석 간 거리, 장착 카드에 따른 거리 보정을 계산한다.
- 제외: UI 대상 강조, 개별 능력 효과
- 산출물: 재사용 가능한 합법성/거리 순수 함수
- 수락 기준: 좌석 수와 탈락 좌석을 포함한 원형 거리 예제가 규칙대로 계산된다. 무기 사거리와 거리 보정이 서로 다른 규칙을 중복 적용하지 않는다. 불법 대상 선택은 거부된다.

#### T12 — 카드 해결과 반응 프레임워크

- 상태: TODO
- 의존: T06, T10, T11
- 파일 소유: packages/engine/src/resolution/**, packages/engine/test/resolution/**
- 입력: 01_RULES.md, 04_PROTOCOL.md
- 범위: 해결 중 카드, 순차 effectQueue, 응답 대기 좌석, 죽음/구제 선택, 후속 continuation을 명시적으로 직렬화하고 재개한다.
- 제외: 개별 카드 효과 내용, 자동 시간 만료
- 산출물: 순수 해결 프레임/응답 큐 API
- 수락 기준: Duel, 다중 대상 공격, 죽음/구제, DISCARDS_ORDER 선택을 저장/복구할 수 있다. 유효 응답은 해당 cursor만 한 번 진행하고 잘못된 응답자는 상태를 바꾸지 못한다. 중간 재시작 뒤 다음 actor와 resume frame이 동일하다.

#### T13 — 탈락 및 승리 판정

- 상태: TODO
- 의존: T06, T10, T12
- 파일 소유: packages/engine/src/endgame/**, packages/engine/test/endgame/**
- 입력: 01_RULES.md
- 범위: 생명력 0 구제 완료, 역할 공개/탈락, Vulture Sam 회수, 소유자 지정 버리기 순서, 처치 보상 및 효과 완료 경계의 승리 판정을 처리한다.
- 제외: 결과 화면, 랭킹/통계
- 산출물: 탈락 처리 및 게임 종료 판정 함수
- 수락 기준: Beer/Sid 구제 완료 또는 포기 뒤에만 탈락 처리를 시작한다. Vulture Sam이 살아 있으면 손패/장착을 먼저 자신의 손패로 회수하고, 없으면 탈락자가 공개 카드 정리 순서를 입력한다. 무법자 처치 보상과 보안관의 부관 처치 벌칙 순서를 확인한다. 승리는 multi-target 효과의 마지막 대상/후처리 완료 뒤 한 번만 검사한다.

#### T14 — 엔진 명령 처리기

- 상태: TODO
- 의존: T02, T06, T10, T11, T12, T13
- 파일 소유: packages/engine/src/commands/**, packages/engine/test/commands/**
- 입력: 04_PROTOCOL.md, 06_ACCEPTANCE_TESTS.md
- 범위: 검증된 도메인 명령의 현재 actor/단계/카드/대상 합법성을 확인하고 엔진 전이 또는 규칙상 거절 결과를 만든다.
- 제외: 인증, aggregate expectedVersion 비교, command receipt/idempotency, 저장소, 네트워크 전달
- 산출물: 순수 엔진 명령 적용 API
- 수락 기준: 불법 명령은 상태를 바꾸지 않고 명시적 규칙 오류를 반환한다. 같은 상태·명령·준비된 RNG 결과에 같은 전이와 이벤트가 나온다. expectedVersion/idempotency 처리는 T46 서버 경계에 한 번만 존재한다.

#### T15 — 카드 효과 모듈 인터페이스

- 상태: TODO
- 의존: T06, T11, T12
- 파일 소유: packages/engine/src/effects/api.ts, packages/engine/test/effects/api.test.ts
- 입력: 01_RULES.md, 03_ARCHITECTURE.md, 04_PROTOCOL.md
- 범위: 카드별 효과 모듈이 받는 상태, 대상, 난수, 응답 요청, 결과 이벤트의 최소 계약을 정의한다.
- 제외: 효과 등록기, 카드 규칙 구현, 공용 상태 변경
- 산출물: 고정된 카드 효과 API 타입
- 수락 기준: 후속 카드 모듈이 공용 reducer 수정 없이 효과를 작성할 수 있다. 대상이 없거나 불법인 경우, 선택/응답이 필요한 경우를 API가 구분한다. 타입에는 클라이언트 전용 UI 의존성이 없다.

### W3 — 기본 카드 효과 모듈

각 작업은 자신의 효과 파일과 전용 테스트만 소유한다. 공용 reducer/state/effect API 수정은 제외한다.

#### T16 — BANG!, 빗나감!, 맥주

- 상태: TODO
- 의존: T11, T12, T13, T15
- 파일 소유: packages/engine/src/effects/cards/basic-actions.ts, packages/engine/test/effects/basic-actions.test.ts
- 입력: 01_RULES.md
- 범위: BANG! 사용/대응, 빗나감! 응답, 맥주의 회복 규칙을 모듈화한다.
- 제외: 무기/인물 능력에 따른 카드 사용 제한 자체의 공용 API 변경
- 산출물: 세 기본 행동 카드 효과와 경우별 테스트
- 수락 기준: BANG 사용 횟수와 Missed 대응이 구분되고, 맥주는 최대 체력까지만 회복한다. 2인 Beer, 2인 자기 턴 사용, 구제용 Beer의 차이를 테스트한다. 모든 결과가 기본 ruleset과 일치한다.

#### T17 — 패닉!과 캣 벌루

- 상태: TODO
- 의존: T11, T12, T15
- 파일 소유: packages/engine/src/effects/cards/steal-discard.ts, packages/engine/test/effects/steal-discard.test.ts
- 입력: 01_RULES.md
- 범위: 거리 조건에 맞는 대상의 허용된 카드 영역에서 카드를 가져오거나 버리는 효과를 구현한다.
- 제외: 거리 API 변경, 장착 카드 공용 상태 모델 변경
- 산출물: 패닉!/캣 벌루 효과와 대상/카드 선택 테스트
- 수락 기준: Panic은 인접 상대, Cat Balou는 거리 무관 대상을 처리한다. 손패 대상은 무작위, 공개 장착 카드는 대상이 선택하는 규칙을 확인한다. 자기 대상 정책 D03에 따라 자기 공개 장착은 허용하고 자기 손패는 거부한다. 무작위 선택은 주입 RNG로 재현된다.

#### T18 — 인디언!, 개틀링, 술집

- 상태: TODO
- 의존: T12, T13, T15
- 파일 소유: packages/engine/src/effects/cards/tablewide.ts, packages/engine/test/effects/tablewide.test.ts
- 입력: 01_RULES.md
- 범위: 전체 대상 공격/응답 순서와 전체 회복의 카드 효과를 구현한다.
- 제외: 개별 카드 반응 UI 및 사거리 계산
- 산출물: 광역 카드 효과 모듈과 좌석 순서 테스트
- 수락 기준: Gatling의 Missed/Barrel 대응과 Indians의 BANG 폐기/피해 선택이 다르게 처리된다. Calamity의 변환 예외, Slab 미강화, 사용자 다음 좌석부터의 시계방향 직렬 응답을 테스트한다. 광역 카드로 발생한 모든 탈락/후처리를 끝낸 뒤 승리를 판정한다. Saloon은 자기 포함 생존자 회복이며 2인에도 유효하다.

#### T19 — 역마차, 웰스 파고, 엠포리움

- 상태: TODO
- 의존: T12, T15
- 파일 소유: packages/engine/src/effects/cards/draw-select.ts, packages/engine/test/effects/draw-select.test.ts
- 입력: 01_RULES.md
- 범위: 덱에서 여러 장 뽑기와 엠포리움의 좌석 순서 선택 절차를 구현한다.
- 제외: 덱 셔플, 기본 드로우 단계
- 산출물: 세 카드 효과와 덱 부족/좌석별 선택 테스트
- 수락 기준: Stagecoach 2장, Wells Fargo 3장, General Store는 현재 생존자 수만큼 공개한 뒤 사용자부터 시계방향으로 한 장씩 고른다. 덱/버림더미 고갈은 명시된 재셔플 규칙에 따르고 선택하지 않은 카드는 규칙에 맞는 구역에 남는다.

#### T20 — 결투

- 상태: TODO
- 의존: T12, T15
- 파일 소유: packages/engine/src/effects/cards/duel.ts, packages/engine/test/effects/duel.test.ts
- 입력: 01_RULES.md
- 범위: 두 좌석 간 교대 응답, 응답 소진 및 피해 종료 규칙을 구현한다.
- 제외: UI, 범용 응답 프레임 API 수정
- 산출물: 결투 효과 상태 진행과 테스트
- 수락 기준: 대상은 거리 무관 다른 생존자이고 상대부터 BANG을 번갈아 낸다. Duel 대응 BANG은 자기 턴 사용 횟수를 소모하지 않는다. Calamity 변환과 즉시 종료, Duel 원 개시자가 죽을 때 처치 보상이 없는 규칙을 고정 RNG/fixture로 검증한다.

#### T21 — 감옥

- 상태: TODO
- 의존: T12, T15
- 파일 소유: packages/engine/src/effects/cards/jail.ts, packages/engine/test/effects/jail.test.ts
- 입력: 01_RULES.md
- 범위: 감옥 설치/대상 제한과 차례 시작 시 해결 결과를 구현한다.
- 제외: 턴 순환 공용 reducer 변경, 자동 시간 만료
- 산출물: 감옥 카드 효과와 차례 시작 테스트
- 수락 기준: 보안관이 아닌 다른 생존자에게만 설치되고 차례 시작 시 다이너마이트보다 뒤에 판정한다. Heart면 진행, 아니면 드로우/사용/버리기 전체를 건너뛰며 감옥은 결과와 무관하게 버려진다. 카드 영역과 표시 순서를 검증한다.

#### T22 — 다이너마이트와 배럴

- 상태: TODO
- 의존: T08, T12, T13, T15
- 파일 소유: packages/engine/src/effects/cards/dynamite-barrel.ts, packages/engine/test/effects/dynamite-barrel.test.ts
- 입력: 01_RULES.md
- 범위: 차례 시작 판정, 다음 좌석 이동, 배럴 대응 및 피해를 구현한다.
- 제외: RNG 구현, 공용 턴 reducer 변경
- 산출물: 다이너마이트/배럴 효과와 고정 RNG 테스트
- 수락 기준: 다이너마이트는 감옥보다 먼저 처리되며 Spade 2~9면 피해 3, 아니면 다음 생존 좌석으로 이동한다. 폭발 책임자는 없고 Barrel은 비-BANG 다이너마이트 피해를 막지 않는다. 주입 RNG가 같은 결과를 재현한다.

#### T23 — 무기와 거리 장비

- 상태: TODO
- 의존: T11, T15
- 파일 소유: packages/engine/src/effects/cards/equipment.ts, packages/engine/test/effects/equipment.test.ts
- 입력: 01_RULES.md
- 범위: 무기 교체/장착 및 조준경·무스탕 등 거리 보정 카드의 효과를 구현한다.
- 제외: 공용 거리 함수 변경, 카드 UI
- 산출물: 장착 효과와 거리 보정 테스트
- 수락 기준: 무기별 사거리 1~5와 무기 1개 장착 제한을 대조한다. Volcanic 장착 중 BANG 무제한이어도 잃은 뒤 턴 사용 횟수는 초기화되지 않는다. 상대 Mustang/Paul과 자신의 Scope/Rose 보정이 비대칭 거리 공식에 적용된다.

#### T24 — 차례 종료 손패 버리기

- 상태: TODO
- 의존: T10, T15
- 파일 소유: packages/engine/src/effects/cards/hand-limit.ts, packages/engine/test/effects/hand-limit.test.ts
- 입력: 01_RULES.md
- 범위: 차례 종료 시 손패 제한과 초과 카드 폐기 계산을 구현한다.
- 제외: 공용 차례 reducer 변경, 버리기 선택 UI
- 산출물: 손패 제한 효과와 체력 변화 경계 테스트
- 수락 기준: 턴 종료 손패는 현재 HP 이하가 되며 필요한 초과분만 버린다. 손패와 장착 카드의 임의 폐기를 허용하지 않고 여러 장 순서는 소유자의 배열대로 기록한다. 종료/탈락 정리 순서와 턴 손패 제한을 구분한다.

### W3 — 인물별 효과 모듈

각 작업의 효과는 지정된 단일 파일에 둔다. 인물의 시작 능력/지속 효과/대응 능력을 01_RULES.md에 기록된 범위 안에서만 구현한다. 카드 인물 파일, 등록기, 공유 API 수정은 제외한다.

#### T25 — Bart Cassidy

- 상태: TODO
- 의존: T11, T12, T15
- 파일 소유: packages/engine/src/effects/characters/bart-cassidy.ts, packages/engine/test/effects/characters/bart-cassidy.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: 피해 수신 능력 모듈
- 수락 기준: 생존한 상태로 잃은 HP당 덱 1장을 얻고 Dynamite 3 피해를 버텨도 3장을 얻는다. 치명상 구제 창에서 능력으로 Beer를 찾아 구제할 수 없고, 다른 인물은 발동하지 않는다.

#### T26 — Black Jack

- 상태: TODO
- 의존: T08, T12, T15
- 파일 소유: packages/engine/src/effects/characters/black-jack.ts, packages/engine/test/effects/characters/black-jack.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: 시작 카드 추가 공개/획득 모듈
- 수락 기준: 뽑기 단계 두 번째 카드만 공개한다. Heart/Diamond면 추가 덱 카드 1장을 비공개로 얻으며, Black Jack 공개는 Draw! 판정이 아니고 추가 뽑기에는 능력이 반복되지 않는다.

#### T27 — Calamity Janet

- 상태: TODO
- 의존: T11, T12, T15
- 파일 소유: packages/engine/src/effects/characters/calamity-janet.ts, packages/engine/test/effects/characters/calamity-janet.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: 카드 대체 사용 능력 모듈
- 수락 기준: BANG을 Missed로, Missed를 BANG으로 일반 사용/대응할 수 있다. BANG 변환은 턴 BANG quota를 쓰고 Duel/Indians 대응에도 변환 BANG이 허용된다. 다른 인물은 변환하지 않는다.

#### T28 — El Gringo

- 상태: TODO
- 의존: T12, T15
- 파일 소유: packages/engine/src/effects/characters/el-gringo.ts, packages/engine/test/effects/characters/el-gringo.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: 피해 출처 손패 획득 능력 모듈
- 수락 기준: 다른 플레이어의 사용 카드로 HP를 잃고 생존한 경우 HP당 해당 사용자의 손패를 무작위 1장씩 가져온다. 상대 손패가 없으면 얻지 않는다. Dynamite/자신이 연 Duel에서 진 경우에는 발동하지 않는다.

#### T29 — Jesse Jones

- 상태: TODO
- 의존: T08, T12, T15
- 파일 소유: packages/engine/src/effects/characters/jesse-jones.ts, packages/engine/test/effects/characters/jesse-jones.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: 시작 뽑기 대체 선택 모듈
- 수락 기준: 뽑기 단계 첫 카드만 다른 생존자의 손패에서 무작위로 가져오거나 덱에서 받는다. 두 번째 카드는 덱에서 뽑으며 빈 상대 손패의 처리가 룰 문서와 같다.

#### T30 — Jourdonnais

- 상태: TODO
- 의존: T08, T12, T15
- 파일 소유: packages/engine/src/effects/characters/jourdonnais.ts, packages/engine/test/effects/characters/jourdonnais.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: 피해 회피 판정 모듈
- 수락 기준: BANG-symbol 공격마다 가상 Barrel 판정을 한 번 한다. Heart면 Missed 1개로 인정한다. 실제 Barrel도 장착한 경우 판정이 각각 한 번 적용되고, 비공격 피해에는 판정하지 않는다.

#### T31 — Kit Carlson

- 상태: TODO
- 의존: T08, T12, T15
- 파일 소유: packages/engine/src/effects/characters/kit-carlson.ts, packages/engine/test/effects/characters/kit-carlson.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: 시작 카드 선택 뽑기 모듈
- 수락 기준: 뽑기 단계 덱 3장을 본인만 보고 2장 손패에 넣으며, 남은 1장을 덱 맨 위에 비공개로 돌려놓는다. 다른 viewer projection에서 선택 후보를 숨긴다.

#### T32 — Lucky Duke

- 상태: TODO
- 의존: T08, T12, T15
- 파일 소유: packages/engine/src/effects/characters/lucky-duke.ts, packages/engine/test/effects/characters/lucky-duke.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: 판정 복수 공개 능력 모듈
- 수락 기준: Draw!마다 2장을 공개하고 Lucky가 선택한 한 장으로 무늬/숫자를 판정한 뒤 두 장 모두 버린다. 일반 뽑기와 Black Jack 추가 뽑기에서는 적용되지 않는다. 두 장의 버림 순서는 D04를 따른다.

#### T33 — Paul Regret

- 상태: TODO
- 의존: T11, T15
- 파일 소유: packages/engine/src/effects/characters/paul-regret.ts, packages/engine/test/effects/characters/paul-regret.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: 다른 플레이어의 거리 보정 모듈
- 수락 기준: 상대가 Paul Regret에게 계산하는 자기 거리에 +1을 적용하고 Mustang과 누적한다. Rose/Scope 및 탈락 좌석을 포함한 방향별 거리 fixture가 R10 공식과 일치한다.

#### T34 — Pedro Ramirez

- 상태: TODO
- 의존: T08, T12, T15
- 파일 소유: packages/engine/src/effects/characters/pedro-ramirez.ts, packages/engine/test/effects/characters/pedro-ramirez.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: 시작 버림 더미 카드 획득 모듈
- 수락 기준: 뽑기 단계 첫 카드는 버림 더미 top을 선택할 수 있고, 그 뒤 두 번째 카드는 덱에서 뽑는다. 버림 더미가 비면 대체 선택이 없으며, 덱이 비어도 규칙상 먼저 top을 가져올 수 있는 경우를 확인한다.

#### T35 — Rose Doolan

- 상태: TODO
- 의존: T11, T15
- 파일 소유: packages/engine/src/effects/characters/rose-doolan.ts, packages/engine/test/effects/characters/rose-doolan.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: 대상 거리 보정 모듈
- 수락 기준: Rose가 자신에게 계산하는 상대까지 거리에서 -1, 최소 1을 적용한다. 상대가 Rose에게 계산하는 거리에는 적용하지 않고 Scope와 누적한다.

#### T36 — Sid Ketchum

- 상태: TODO
- 의존: T12, T13, T15
- 파일 소유: packages/engine/src/effects/characters/sid-ketchum.ts, packages/engine/test/effects/characters/sid-ketchum.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: 손패 폐기 회복 능력 모듈
- 수락 기준: 손패 정확히 2장 폐기로 HP 1 회복이 반복 가능하고 최대 HP를 넘지 않는다. 자기 사용 단계와 치명상 구제에만 열리며 다른 카드 해결 중 임의 끼어들기는 거부한다. 2인 상태에서도 Sid 회복은 유효하다.

#### T37 — Slab

- 상태: TODO
- 의존: T12, T15
- 파일 소유: packages/engine/src/effects/characters/slab.ts, packages/engine/test/effects/characters/slab.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: BANG! 대응 추가 비용 모듈
- 수락 기준: Slab의 자기 BANG 카드 공격에만 Missed 2개가 요구된다. Barrel 성공은 1개로 인정되고 Gatling은 강화하지 않는다. Missed 1개만 낸 뒤 나머지를 포기해 피해를 받을 수 있다.

#### T38 — Suzy Lafayette

- 상태: TODO
- 의존: T12, T15
- 파일 소유: packages/engine/src/effects/characters/suzy-lafayette.ts, packages/engine/test/effects/characters/suzy-lafayette.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: 손패 없음 상태 능력 모듈
- 수락 기준: 손패가 0장이 된 순간 덱에서 1장을 얻는다. 마지막 Slab 대응 Missed 뒤에는 즉시 발동해 새 Missed로 두 번째 대응을 계속할 수 있다. 마지막 Duel과 General Store의 발동 경계도 구분한다.

#### T39 — Vulture Sam

- 상태: TODO
- 의존: T12, T13, T15
- 파일 소유: packages/engine/src/effects/characters/vulture-sam.ts, packages/engine/test/effects/characters/vulture-sam.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: 탈락 처리 중 카드 획득 모듈
- 수락 기준: 다른 플레이어 탈락 시 손패와 장착 카드를 자신의 손패로 회수하며 자동 장착하지 않는다. 폭발한 Dynamite는 이미 폐기되어 회수되지 않고, 이미 처리된 탈락은 중복 회수하지 않는다.

#### T40 — Willy the Kid

- 상태: TODO
- 의존: T11, T15
- 파일 소유: packages/engine/src/effects/characters/willy-the-kid.ts, packages/engine/test/effects/characters/willy-the-kid.test.ts
- 입력: 01_RULES.md, T05 카탈로그 산출물
- 산출물: BANG! 횟수 제한 능력 모듈
- 수락 기준: 자기 턴 BANG 횟수 제한이 없어지지만 사거리와 유효 대상 제한은 유지된다. 다른 인물의 제한과 Volcanic 상실 후 횟수 누적은 바뀌지 않는다.

#### T41 — 효과 모듈 등록기

- 상태: TODO
- 의존: T15~T40
- 파일 소유: packages/engine/src/effects/registry.ts, packages/engine/test/effects/registry.test.ts
- 입력: 03_ARCHITECTURE.md, T04/T05 카탈로그 산출물
- 범위: 기본 카드와 16종 인물 효과를 식별자 기반으로 연결한다.
- 제외: 개별 효과 파일 변경, 런타임 플러그인 검색
- 산출물: 타입이 확인되는 단일 정적 효과 등록기
- 수락 기준: 모든 기본판 카드 효과 및 인물 효과 ID가 한 번 등록되고, 중복 또는 없는 ID 요청은 명시적으로 거부된다. 새 등록은 effect API를 구현한 모듈만 수용한다.

#### T42 — 엔진 시나리오 수락 테스트

- 상태: TODO
- 의존: T04~T24, T25~T41
- 파일 소유: packages/engine/test/scenarios/**, packages/test-fixtures/engine/**
- 입력: 01_RULES.md, 06_ACCEPTANCE_TESTS.md
- 범위: AT-A01~AT-A15, AT-B01~AT-B30, AT-C01~AT-C32와 카드 구역 불변조건 AT-D20을 고정 RNG/덱으로 검증한다.
- 제외: 웹 UI, 실제 네트워크 연결
- 산출물: 규칙 사례 기반 엔진 시나리오와 fixture
- 수락 기준: 06_ACCEPTANCE_TESTS.md의 78개 엔진 사례가 각각 테스트에 연결된다. 동일 입력 반복 실행의 상태와 이벤트 출력이 같고, projection의 비공개 필드 누출 검사 및 매 단계 80장 중복 소유/누락 검사가 포함된다. 사례 ID는 AT-A01처럼 접두사를 포함해 추적하며, AT-D01~AT-D19 서버/브라우저 사례는 T60이 소유한다.

### W4/W5 — 서버와 실시간 동기화

#### T43 — PostgreSQL 버전 관리 저장소

- 상태: TODO
- 의존: T02, T06
- 파일 소유: apps/server/src/storage/**, apps/server/migrations/**, apps/server/test/storage/**
- 입력: 03_ARCHITECTURE.md
- 범위: PostgreSQL 스키마/migration과 저장/로드 repository를 구현한다. room, match snapshot, event, command receipt, outbox가 03_ARCHITECTURE/04_PROTOCOL의 트랜잭션 경계를 따른다.
- 제외: 방 정책, 클라이언트 전송
- 산출물: 버전 포함 저장/복구 어댑터와 어댑터 테스트
- 수락 기준: 저장 후 읽은 상태가 직렬화 의미상 동일하고, 낮은 버전 저장은 거절된다. snapshot/version/event/receipt/outbox가 한 DB 트랜잭션으로 원자 커밋된다. migration이 빈 PostgreSQL DB에서 적용되고 테스트 후 상태/영수증을 조회할 수 있다.

#### T44 — 비공개 초대방 및 게스트 좌석 서비스

- 상태: TODO
- 의존: T02, T43
- 파일 소유: apps/server/src/rooms/**, apps/server/test/rooms/**
- 입력: 02_PRODUCT_UX.md, 03_ARCHITECTURE.md, 04_PROTOCOL.md
- 범위: 비공개 방 생성, 초대 코드 발급/입장, 게스트 좌석 배정, 재접속 credential, 방 보존 및 시간 제한 설정을 구현한다.
- 제외: 공개 로비/매칭, 사용자 계정, 기본 자동 턴 timeout
- 산출물: 룸/게스트 세션 서비스와 서비스 테스트
- 수락 기준: 유효한 초대 코드 preview와 JOIN 없이 비공개 방에 들어갈 수 없다. 방 인원은 4~7명이며 중복 좌석/8번째 입장을 막는다. 방장이 명시적으로 나가면 남은 좌석 중 가장 먼저 입장한 참가자에게 소유권을 넘긴다. 시간 만료 동작 기본값은 OFF이며 재접속 credential은 지정 좌석만 복구한다.

#### T45 — Socket.IO 세션 게이트웨이

- 상태: TODO
- 의존: T02, T44
- 파일 소유: apps/server/src/socket/**, apps/server/test/socket/**
- 입력: 03_ARCHITECTURE.md, 04_PROTOCOL.md
- 범위: 연결 handshake, 룸 가입, 이벤트 envelope 검증, disconnect 처리를 프로토콜에 매핑한다.
- 제외: 엔진 규칙 계산, 별도 HTTP 제품 API
- 산출물: Socket.IO 게이트웨이와 연결 계약 테스트
- 수락 기준: 쿠키 세션을 handshake에서 인증하고, match/room membership은 sync 및 각 명령에서 다시 확인한다. 계약에 없는 이벤트/잘못된 envelope/임의 채널 가입은 거부된다. disconnect가 좌석 제거/탈락으로 바뀌지 않는다.

#### T46 — 권한/버전/idempotency 명령 중계

- 상태: TODO
- 의존: T14, T43, T44, T45
- 파일 소유: apps/server/src/commands/**, apps/server/test/commands/**
- 입력: 04_PROTOCOL.md, 06_ACCEPTANCE_TESTS.md
- 범위: 연결 세션 좌석과 게임 버전을 확인하고 엔진에 유효 명령을 한 번 적용한 뒤 저장한다.
- 제외: projection 브로드캐스트, UI optimistic state
- 산출물: 검증된 명령 중계기와 중복/버전 경계 테스트
- 수락 기준: 플레이어는 다른 좌석 명령을 제출할 수 없다. stale expectedVersion은 저장 상태를 바꾸지 않는다. engine output, snapshot, version, events, receipt, outbox가 한 트랜잭션에 반영된다. 같은 idempotency key 재전송은 같은 outcome을 반환하며 게임 효과와 저장 이벤트를 중복시키지 않는다.

#### T47 — 인증된 sync projection과 변경 알림

- 상태: TODO
- 의존: T07, T45, T46
- 파일 소유: apps/server/src/projections/**, apps/server/test/projections/**
- 입력: 04_PROTOCOL.md, 06_ACCEPTANCE_TESTS.md
- 범위: 인증된 match:sync/room:sync 요청에서 actor 권한을 다시 확인하고 필요한 전체 스냅샷/공개 이벤트를 viewer projection으로 응답한다. outbox 알림은 새 버전이 있다는 무효화 정보만 싣는다.
- 제외: projection 브로드캐스트, UI 상태 저장, 역할 공개 규칙 재정의
- 산출물: sync projection 응답기와 비공개 필드/무효화 outbox 테스트
- 수락 기준: sync 응답은 authenticated player 기준의 PlayerView와 필요한 이벤트 projection이다. 다른 좌석 손패/역할, 전체 GameState, effectQueue 및 invite 원문이 sync/outbox payload에 없다. outbox에는 aggregate ID/version/eventSeq만 포함하고 상태 본문을 넣지 않는다. 재생할 수 없는 cursor는 requiresFullSnapshot으로 응답한다.

#### T48 — 연결 복구와 저장 상태 재개

- 상태: TODO
- 의존: T43, T44, T46, T47
- 파일 소유: apps/server/test/recovery/**, apps/server/src/recovery/**
- 입력: 03_ARCHITECTURE.md, 04_PROTOCOL.md, 06_ACCEPTANCE_TESTS.md
- 범위: disconnect 또는 서버 재시작 뒤 세션 credential과 membership으로 원 좌석을 복구하고 최신 sync, 공개 이벤트 이력, 현재 pending 상태를 반환한다.
- 제외: 클라이언트 화면 구현, 재접속 정책을 벗어난 계정 시스템
- 산출물: 복구 핸들러와 다중 연결 통합 테스트
- 수락 기준: Duel, DEATH_RESCUE, DISCARDS_ORDER, multi-target effectQueue 중간에 서버를 재시작해도 동일 좌석·cursor·resume frame·자기 비공개 상태가 복원된다. 같은 commandId는 receipt로 한 번만 반영된다. 비인가 projection/outbox에 사적 정보가 없다. 미지원 schema/ruleset은 자동 진행하지 않고 recovery_required로 격리한다.

#### T49 — 서버 실행 진입점과 환경 설정

- 상태: TODO
- 의존: T43~T48
- 파일 소유: apps/server/src/main.ts, apps/server/src/config.ts, apps/server/README.md, apps/server/test/runtime/**
- 입력: 03_ARCHITECTURE.md
- 범위: 개발용 환경 변수 검증, Socket.IO 서버 조립, 종료 처리, 로컬 실행 설명을 제공한다.
- 제외: 배포 플랫폼 설정, 제품 분석 이벤트
- 산출물: 재현 가능한 서버 시작 진입점과 설정 문서
- 수락 기준: 필수 설정 누락 시 명시적인 시작 오류를 낸다. 개발 환경에서 PostgreSQL 연결 및 schema migration을 확인하고 POST /api/guest-sessions와 Socket.IO 서버를 올린다. 세션 credential은 HttpOnly/Secure 쿠키로만 돌려주고 원본 token을 로그에 남기지 않는다. 문서의 로컬 서버 명령이 준비 상태까지 도달한다.

### W6/W7 — 브라우저 클라이언트

#### T50 — React 앱 셸과 라우팅

- 상태: TODO
- 의존: T01, T02
- 파일 소유: apps/web/src/app/**
- 입력: 02_PRODUCT_UX.md, 03_ARCHITECTURE.md
- 범위: 앱 셸, 페이지 라우팅, 공통 로딩/오류 프레임과 전역 상태 경계를 만든다.
- 제외: 방 로비/게임 세부 UI
- 산출물: React/Vite 앱 진입점과 페이지 뼈대
- 수락 기준: Vite 개발 서버에서 앱 셸과 정의된 경로가 로드된다. 잘못된 경로는 안내 상태를 보이고 콘솔 오류나 타입 오류 없이 빌드된다.

#### T51 — 방 만들기와 초대 입장 화면

- 상태: TODO
- 의존: T02, T44, T50
- 파일 소유: apps/web/src/features/room-entry/**
- 입력: 02_PRODUCT_UX.md, 04_PROTOCOL.md
- 범위: 게스트 이름, 새 비공개 방 생성, 초대 코드 입력, 세션 보관/오류 안내 UI를 구현한다.
- 제외: 외부 계정 로그인, 공개 매칭
- 산출물: 룸 진입 경로 및 로딩/실패 상태
- 수락 기준: 먼저 guest session을 생성하고 난 뒤 방을 만들거나 초대 코드 preview/JOIN 절차로 입장한다. 초대 preview와 입장 version이 포함되고 유효하지 않은 코드는 같은 방식으로 거절된다. 초대 URL에는 session secret이 없으며 새로고침 뒤 쿠키 credential로 같은 좌석을 복구한다.

#### T52 — 대기실 및 시작 준비 UI

- 상태: TODO
- 의존: T44, T45, T50
- 파일 소유: apps/web/src/features/lobby/**
- 입력: 02_PRODUCT_UX.md, 04_PROTOCOL.md
- 범위: 좌석 입장/퇴장, 게스트 표시, 준비/시작 가능 상태, 초대 코드 공유 화면을 구현한다.
- 제외: 게임 중 카드 행동
- 산출물: 비공개 방 대기실 뷰와 이벤트 바인딩
- 수락 기준: 4~7명 대기실의 참가 좌석과 준비 상태가 서버 상태와 일치한다. 4명 미만 시작과 8번째 입장은 막고 게임 시작 후 kick/중간 입장을 거부한다. 방장만 시작 가능하며 방/인원 상태가 안내된다.

#### T53 — 게임 테이블과 좌석 상태 표시

- 상태: TODO
- 의존: T02, T07, T50
- 파일 소유: apps/web/src/features/game-table/**
- 입력: 02_PRODUCT_UX.md, 04_PROTOCOL.md
- 범위: 자신의 자리와 상대 자리, 공개 체력/장착/역할 공개 상태를 projection 기준으로 배치한다.
- 제외: 카드 사용 인터랙션, 서버 상태 자체 생성
- 산출물: 반응형 테이블 프레젠테이션 컴포넌트
- 수락 기준: 생존자/탈락자 projection fixture가 허용 정보만 표시한다. 공개 역할을 포함해도 아직 비공개인 상대 역할, 손패, 덱 순서는 DOM/접근성 이름 어디에도 나타나지 않는다. 공개 손패 수와 버림 top/수량만 표시한다.

#### T54 — 카드 앞면, 손패, 보유 카드 렌더링

- 상태: TODO
- 의존: T04, T05, T53
- 파일 소유: apps/web/src/features/cards/**, apps/web/public/assets/cards/**, apps/web/src/features/cards/attribution.tsx
- 입력: outputs/assets/ASSET_INVENTORY.md, outputs/assets/asset_manifest.csv, outputs/assets/ATTRIBUTION.md, 02_PRODUCT_UX.md
- 범위: 제공된 플레이/인물/역할 42개 카드면을 웹 public 폴더로 복사하고, catalog의 80장별 rank/suit를 이미지에 겹쳐 렌더링한다. 원본 숫자/무늬가 인스턴스 값과 다르면 해당 인쇄 영역을 가리거나 삽화 영역만 써서 중복 문양/숫자를 막는다.
- 제외: source_images 원본 재가공/삭제, 카드 효과, 추가 외부 이미지 수집
- 산출물: 카드 렌더러, public asset manifest mapping, rank/suit frame 및 출처 크레딧 링크
- 수락 기준: 22 플레이 카드형·16 인물·4 역할 이미지 경로가 실제 public 파일과 맞는다. 권한 있는 본인 손패/공개 카드 face에는 각 물리 인스턴스의 catalog rank/suit가 표시되고, 인쇄 rank/suit와 중복/충돌하지 않는다. 상대 손패는 rank/suit 없이 뒷면으로 보인다. 특히 Stagecoach 두 장은 별도 ID를 유지하며 둘 다 Spade 9로 표시된다. 이미지가 없어도 텍스트 fallback/출처가 보이고 빈 대체 텍스트가 없다.

#### T55 — 행동 선택과 합법 대상 UI

- 상태: TODO
- 의존: T02, T11, T14, T54
- 파일 소유: apps/web/src/features/actions/**
- 입력: 02_PRODUCT_UX.md, 04_PROTOCOL.md
- 범위: 서버 projection이 제공한 합법 행동과 대상을 표시하고 명령 제출 전 선택을 수집한다.
- 제외: 클라이언트 자체 규칙 계산, optimistic server authority 대체
- 산출물: 카드 선택/대상 선택/명령 제출 UI
- 수락 기준: 제출 envelope가 계약의 expectedVersion/idempotency 필드를 가진다. 비합법 대상은 선택 불가하다. 서버 거절 후 화면은 최신 projection에 맞게 복구된다.

#### T56 — 반응 프롬프트

- 상태: TODO
- 의존: T02, T12, T15
- 파일 소유: apps/web/src/features/reactions/**
- 입력: 02_PRODUCT_UX.md, 04_PROTOCOL.md
- 범위: 빗나감, 결투, 감옥 등 해결 프레임워크가 전달한 응답 대기 상태를 표시하고 유효 응답을 제출한다.
- 제외: 해결 순서 규칙, 타이머 기본값 활성화
- 산출물: 응답 프롬프트와 선택 제어
- 수락 기준: multi-target 순차 응답, DEATH_RESCUE, DISCARDS_ORDER, Vulture Sam 후처리에서 현재 응답 좌석만 조작할 수 있다. 비응답 좌석은 진행 신호만 보고 남의 선택지를 보지 않는다. 재접속 sync 뒤 같은 pending prompt가 돌아온다.

#### T57 — 차례, 로그, 결과 표시

- 상태: TODO
- 의존: T02, T13, T50
- 파일 소유: apps/web/src/features/status/**
- 입력: 02_PRODUCT_UX.md, 04_PROTOCOL.md
- 범위: 현재 차례/단계, 공개 게임 이벤트, 종료 결과를 표시한다.
- 제외: 기록 서버, 랭킹/통계
- 산출물: 진행 상태, 로그, 승패 결과 UI
- 수락 기준: 공개 eventSeq/version 순서로 이벤트를 중복 없이 표시하고 숨겨진 eventSeq 누락을 허용한다. 내부 state나 손패/역할 비공개 이벤트는 로그에 나오지 않는다. 종료 후 행동 입력이 닫힌다.

#### T58 — 브라우저 Socket.IO 동기화와 재접속

- 상태: TODO
- 의존: T02, T45, T47, T48, T51, T53
- 파일 소유: apps/web/src/transport/**
- 입력: 04_PROTOCOL.md, 06_ACCEPTANCE_TESTS.md
- 범위: 변경 알림 수신 뒤 인증된 room:sync/match:sync로 재조회하고 event version, reconnect cookie, requiresFullSnapshot, pending commandId를 관리한다.
- 제외: 서버 재전송 정책 변경, 로컬 상태를 권위 상태로 승격
- 산출물: 타입이 지정된 전송 client 및 상태 연결 hook
- 수락 기준: match:changed/room:changed outbox 신호는 projection 데이터가 아닌 sync trigger로 처리한다. 중복/역순 버전 알림은 화면을 퇴행시키지 않는다. reconnect 뒤 별도 sync를 항상 호출하고 pending commandId를 같은 payload로 안전하게 재시도한다.

#### T59 — 반응형 및 키보드 접근성 정리

- 상태: TODO
- 의존: T50~T58
- 파일 소유: apps/web/src/styles/accessibility.css, apps/web/src/components/accessibility/**
- 입력: 02_PRODUCT_UX.md, 06_ACCEPTANCE_TESTS.md
- 범위: 기존 화면 요소의 모바일 레이아웃, 키보드 초점, 버튼 이름, 상태 안내를 마무리한다.
- 제외: UI 기능/게임 규칙, 시각 디자인 전체 재설계
- 산출물: 공통 접근성 스타일과 필요한 표시 컴포넌트
- 수락 기준: 주요 게임 행동을 키보드만으로 수행할 수 있다. 카드/대상/응답 컨트롤은 읽을 수 있는 이름과 초점 표시를 갖는다. 화면 폭이 좁을 때 손패와 응답 선택을 가로 스크롤로 조작할 수 있다.

#### T60 — 전체 브라우저 수락 흐름

- 상태: TODO
- 의존: T42, T49, T51~T59
- 파일 소유: apps/web/e2e/**, apps/web/README.md의 수락 흐름 절
- 입력: 06_ACCEPTANCE_TESTS.md, 07_READINESS.md
- 범위: 네 개 이상의 게스트 브라우저 세션으로 초대, 게임, 비공개 projection, 재접속 및 종료까지 연결 검증한다.
- 제외: 공개 배포, 부하/성능 수치 주장
- 산출물: 자동화된 전체 흐름과 실행/결과 기록
- 수락 기준: AT-D01~AT-D19를 통합 환경에서 실제 실행한다. 게스트 브라우저 네 개와 일곱 개 세션 각각으로 한 판을 끝까지 진행해 4인/7인 결과를 모두 확인한다. 상대 손패/비공개 역할이 노출되지 않는다. 다중 대상/죽음 정리 입력 중 한 클라이언트 재접속 뒤 현재 단계가 복원되고 동일 명령 재전송은 중복 적용되지 않는다. 결과는 AT- 접두사 케이스 ID, 커밋, 환경, 실행 명령, 실제 결과로 남는다.

## 차단 질문 등록 규칙

규칙 질문이 생기면 오케스트레이터가 이 실행 계획에 이어 붙이는 차단 질문 등록부에 다음 필드로 기록한다: 질문 ID, 관련 01_RULES.md 절/원문 출처, 막힌 작업 ID, 선택 가능한 판정, 루트 규칙 담당자의 결정, 갱신된 문서 버전. 에이전트는 자체 판단으로 질문을 종결하지 않는다. 질문과 무관한 작업은 계속할 수 있다.

| 질문 ID | 관련 규칙/출처 | 막힌 작업 | 필요한 결정 | 상태/결정 문서 |
|---|---|---|---|---|

## 완료 정의

한 작업은 구현 파일이 있다는 이유만으로 DONE이 되지 않는다. 명시된 산출물 경로만 바뀌었는지 검토하고, 각 수락 기준을 재현할 테스트/검토 증거를 작업 결과에 남기고, 파일 소유권 및 입력 문서와의 일치 여부를 게이트 담당자가 확인해야 한다. 이번 문서는 작업을 계획할 뿐 어떤 작업도 완료 상태로 표시하지 않는다.
